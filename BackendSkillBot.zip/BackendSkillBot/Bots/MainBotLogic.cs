﻿// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

using System;
using Microsoft.Bot.Connector;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Schema;
using Newtonsoft.Json;
using BackendSkillBot.Services;
using System.Linq;
using BackendSkillBot.Models;
using Newtonsoft.Json.Linq;
using System.IO;

namespace BackendSkillBot.Bots
{
    public class MainBotLogic : ActivityHandler
    {
        private readonly ICosmosDbService _cosmosDbService;
        public MainBotLogic(ICosmosDbService cosmosDbService)
        {
            _cosmosDbService = cosmosDbService;
        }


        protected override async Task OnMembersAddedAsync(IList<ChannelAccount> membersAdded, ITurnContext<IConversationUpdateActivity> turnContext, CancellationToken cancellationToken)
        {
            foreach (var member in membersAdded)
            {
                // Greet anyone that was not the target (recipient) of this message.
                if (member.Id != turnContext.Activity.Recipient.Id)
                {
                    await turnContext.SendActivityAsync(MessageFactory.Text("Greetings!"), cancellationToken);
                }
            }
        }

        protected override async Task OnMessageActivityAsync(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            var conId = "a:1RqExsfzdWPONBjn3kcYluJqGLX4Qp5FYxFfgnD93xu3y-Hb_vSDGsdOekWs3L6JzUz36RTws7rDIb1LUtRx_XLCna3JGtedOPRQkpS-qKxu6Hf5Icy3FUKLXJGywMVOx";

            if (turnContext.Activity.Text.Contains("end") || turnContext.Activity.Text.Contains("stop"))
            {
                // Send End of conversation at the end.
                var messageText = $"ending conversation from the skill...";
                await turnContext.SendActivityAsync(MessageFactory.Text(messageText, messageText, InputHints.IgnoringInput), cancellationToken);
                var endOfConversation = Activity.CreateEndOfConversationActivity();
                endOfConversation.Code = EndOfConversationCodes.CompletedSuccessfully;
                await turnContext.SendActivityAsync(endOfConversation, cancellationToken);
            }
            else
            {
                DataItems dataItems = new DataItems();
                if (turnContext.Activity.Conversation.Id == conId)
                {
                    var messageText = $"starting Else condition";
                    string k = "a:1RqExsfzdWPONBjn3kcYluJqGLX4Qp5FYxFfgnD93xu3y-Hb_vSDGsdOekWs3L6JzUz36RTws7rDIb1LUtRx_XLCna3JGtedOPRQkpS-qKxu6Hf5Icy3FUKLXJGywMVOx";
                    string s = "SELECT * FROM ReferenceStorageDB r WHERE r.agentId=" + '"' + k + '"';

                    await turnContext.SendActivityAsync(MessageFactory.Text(messageText, messageText, InputHints.IgnoringInput), cancellationToken);
                    //messageText = $"Echo: {turnContext.Activity.Text} + {" - "} + {turnContext.Activity.Conversation.Name}";

                    foreach (DataItems item in await _cosmosDbService.GetItemsAsync(s))
                    {
                        dataItems = item;
                    }

                    if (dataItems!=null)
                    {
                        //    await turnContext.SendActivityAsync(MessageFactory.Text(messageText, messageText, InputHints.IgnoringInput), cancellationToken);
                        ConversationReference refer = JsonConvert.DeserializeObject<ConversationReference>(dataItems.BotConversationReference);
                        await MessageHelperClass.getAgentActivtyAsync(messageText, refer, refer.ServiceUrl);
                    }                    
                }                 
                else
                {
                    dataItems = await _cosmosDbService.GetItemAsync(turnContext.Activity.Conversation.Id.ToString());
                    DataItems add = new DataItems();
                    if (dataItems == null)
                    {
                        string var = JsonConvert.SerializeObject(turnContext.Activity.GetConversationReference()).ToString();
                        add.BotConversationReference = var;
                        add.AgentConversationReference = (string)JObject.Parse(File.ReadAllText(@"conversationreference.json")).ToString();
                        add.Id = turnContext.Activity.Conversation.Id;
                        add.AgentId = conId;
                        await _cosmosDbService.AddItemAsync(add);
                    }
                    add = await _cosmosDbService.GetItemAsync(turnContext.Activity.Conversation.Id.ToString());
                    ConversationReference refer = JsonConvert.DeserializeObject<ConversationReference>(add.AgentConversationReference);
                    await MessageHelperClass.getAgentActivtyAsync(turnContext.Activity.Text, refer, refer.ServiceUrl);  
                }
                //await MessageHelperClass.getAgentActivtyAsync(turnContext.Activity.Text);
                //await turnContext.SendActivityAsync(MessageHelperClass.getAgentActivty("message from the Bot")); 
                //var messageText = $"Echo: {turnContext.Activity.Text}";
                
            }
        }

        /*public Boolean isAgentPresent(DataItems dataItems, )
        {
            dataItems.BotConversationReference = JsonConvert.SerializeObject(turnContext.Activity.GetConversationReference());
            dataItems.AgentConversationReference = (string)JObject.Parse(File.ReadAllText(@"conversationreference.json"));
            return true;
        }*/

        protected override Task OnEndOfConversationActivityAsync(ITurnContext<IEndOfConversationActivity> turnContext, CancellationToken cancellationToken)
        {
            // This will be called if the root bot is ending the conversation.  Sending additional messages should be
            // avoided as the conversation may have been deleted.
            // Perform cleanup of resources if needed.
            return Task.CompletedTask;
        }
    }
}
