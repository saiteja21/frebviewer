﻿using System.Collections.Generic;
using System.Threading.Tasks;
using BackendSkillBot.Models;

namespace BackendSkillBot.Services
{
    public interface ICosmosDbService
    {
        Task<IEnumerable<DataItems>> GetItemsAsync(string query);
        Task<DataItems> GetItemAsync(string id);
        Task AddItemAsync(DataItems item);
        Task UpdateItemAsync(string id, DataItems item);
        Task DeleteItemAsync(string id);
    }
}
