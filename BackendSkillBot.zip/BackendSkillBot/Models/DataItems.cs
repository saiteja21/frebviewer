﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace BackendSkillBot.Models
{
    public class DataItems
    {
        [JsonProperty(PropertyName = "id")]
        public string Id { get; set; }

        [JsonProperty(PropertyName = "agentId")]
        public string AgentId { get; set; }  

        [JsonProperty(PropertyName = "botConversationReference")]
        public string BotConversationReference { get; set; }

        [JsonProperty(PropertyName = "agentrsationReference")]
        public string AgentConversationReference { get; set; }

       /* [JsonProperty(PropertyName = "firdaySupportTicketID")]
        public string FirdaySupportTicketID { get; set; }

        [JsonProperty(PropertyName = "isComplete")]
        public bool Completed { get; set; }*/
    }
}
