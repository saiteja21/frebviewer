﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Bot.Schema;
using Newtonsoft.Json;
using Microsoft.Bot.Connector;
using Microsoft.Bot.Connector.Authentication;

namespace BackendSkillBot
{
    public static class MessageHelperClass
    {
        
        public static async Task getAgentActivtyAsync(string message, ConversationReference reffered, string uri)
        {
            MicrosoftAppCredentials microsoftAppCredentials;

            if (reffered.Bot.Id == "28:7b710d4c-23bc-4859-a76a-35b9e88b459e") { 
                microsoftAppCredentials = new MicrosoftAppCredentials("7b710d4c-23bc-4859-a76a-35b9e88b459e", "~blW57CS4_dPzL39.tQ8Eb5Q6~eW~6mx-y");
            }
            else
            {
                microsoftAppCredentials = new MicrosoftAppCredentials("116a4a55-b826-4fb5-a42a-0034df958b5a", "AwZLWY[cL9?a:O2k3VtT6NBpk_[XDZC[");
            }
            Uri url = new Uri(uri);
                      
            ConnectorClient connector = new ConnectorClient(url, microsoftAppCredentials,true);
            await connector.Conversations.SendToConversationAsync(getAgentActivty(message, reffered));
         }
        public static Activity getAgentActivty(string message, ConversationReference refer)
        {
            IMessageActivity replyActivity = Activity.CreateMessageActivity();
            replyActivity.ApplyConversationReference(refer);
            replyActivity.Text = message;
            //await connector.Conversations.SendToConversationAsync(getBotMessageActivty)
            return (Activity)replyActivity; 
        } 

        /*public static Activity getBotMessageActivty(this Activity botActivity)
        {
            IMessageActivity replyActivity = Activity.CreateMessageActivity();

            replyActivity.ReplyToId = botActivity.Id;
            replyActivity.From = new ChannelAccount
            {
                Id = botActivity.Recipient.Id,
                Name = botActivity.Recipient.Name
            };
            replyActivity.Recipient = new ChannelAccount
            {
                Id = botActivity.From.Id,
                Name = botActivity.From.Name
            };
            replyActivity.Conversation = new ConversationAccount
            {
                Id = botActivity.Conversation.Id,
                Name = botActivity.Conversation.Name,
                IsGroup = botActivity.Conversation.IsGroup
            };
            return (Activity)replyActivity;
        }*/
    }
}
