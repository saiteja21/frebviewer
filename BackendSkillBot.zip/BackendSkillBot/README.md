﻿# EchoSkillBot

See [SkillSimpleBotToBot](../) for details on how to configure and run this sample.